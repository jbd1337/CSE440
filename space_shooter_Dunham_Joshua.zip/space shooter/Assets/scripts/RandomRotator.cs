﻿using UnityEngine;
using System.Collections;

public class RandomRotator : MonoBehaviour {
    public float tumble;
    private Rigidbody rb;
    private Vector3 rotationSpeed;
	// Use this for initialization
	void Start () {
        rb = GetComponent<Rigidbody>();
        rotationSpeed = Random.insideUnitSphere * tumble;
	}
    void Update ()
    {
        GetComponent<Transform>().Rotate(rotationSpeed * Time.deltaTime);
    }
}
