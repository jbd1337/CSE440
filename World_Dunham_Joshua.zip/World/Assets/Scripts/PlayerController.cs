﻿using UnityEngine;
using System.Collections;

public class PlayerController : MonoBehaviour
{
    public float speed;
    private float moveX;
    private float moveY;
    public float jumpheight;
    private Rigidbody2D rb;
    // Use this for initialization
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();

    }

    // Update is called once per frame
    void FixedUpdate()
    {
        moveX = Input.GetAxis("Horizontal");
        rb.velocity = new Vector2(moveX * speed, 0.0f);
        if (Input.GetKeyDown("space"))
        {
            transform.Translate(0.0f, jumpheight,0.0f);
        }
    }
}
