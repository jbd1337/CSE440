﻿using UnityEngine;
using System.Collections;

public class PlayerController : MonoBehaviour {
    public float speed;
    private Rigidbody2D rb;
    private Renderer rend;
    private Color original;
    private bool changeColor;
    // Use this for initialization
    void Start () {
        rb = GetComponent<Rigidbody2D>();
        rend = GetComponent<Renderer>();
        original = rend.material.color;
        changeColor = true;
    }
	
	// Update is called once per frame
	void FixedUpdate () {
        float movex = Input.GetAxis("Horizontal");
        
        rb.velocity = new Vector2(movex* speed, 0.0f);
        if (Input.GetKeyDown("c"))
        {
            if (changeColor)
            {
                rend.material.color = Color.red;
                changeColor = false;
            }
            else
            {
                rend.material.color = original;
                changeColor = true;
            }
        }
	}
}
