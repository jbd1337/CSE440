﻿using UnityEngine;
using System.Collections;

public class DestroyByContact1 : MonoBehaviour {

	void OnCollsionEnter2D(Collision2D other){
		if (other.gameObject.tag == "Enemy") {
			Destroy(gameObject);
			Destroy(other.gameObject);
		}
	}
}
