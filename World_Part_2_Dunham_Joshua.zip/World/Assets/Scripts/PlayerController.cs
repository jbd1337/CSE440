﻿using UnityEngine;
using System.Collections;

public class PlayerController : MonoBehaviour
{
    public float speed;
    private float moveX;
    private float moveY;
    public float jumpheight;
    private Rigidbody2D rb;
    public GameObject shot;
    public Transform shotSpawn;
    private float nextFire = 0.0f;
    public float fireRate;
	public bool grounded;
    // Use this for initialization
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
    }
	void OnCollisionEnter2D(Collision2D cool){
		if (cool.gameObject.tag == "ground") {
			grounded = true;
		}
	}
	void OnCollisionExit2D(Collision2D cooler){
		if (cooler.gameObject.tag == "ground") {
			grounded = false;
		}
	}
    // Update is called once per frame
    void Update() {
        if (Input.GetKey("f") && Time.time > nextFire)
        {
            nextFire = Time.time + fireRate;
            GameObject clone = Instantiate(shot, shotSpawn.position, shotSpawn.rotation) as GameObject;
        }
    }
    void FixedUpdate()
    {
        moveX = Input.GetAxis("Horizontal");
        rb.velocity = new Vector2(moveX * speed, 0.0f);
		if (Input.GetKeyDown("space") && grounded)
        {
			rb.AddForce(Vector2.up * jumpheight);
        }
    }
}