﻿using UnityEngine;
using System.Collections;

public class CleanUpBullets : MonoBehaviour {

	void OnTriggerEnter2D(Collider2D cool){
		if (cool.gameObject.tag == "Shot") {
			Destroy(cool.gameObject);
		}
	}
}
