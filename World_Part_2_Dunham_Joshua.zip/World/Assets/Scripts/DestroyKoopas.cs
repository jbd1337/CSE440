﻿using UnityEngine;
using System.Collections;

public class DestroyKoopas : MonoBehaviour {

	void OnCollisionEnter2D(Collision2D other){
		if (other.gameObject.tag == "Shot") {
			Destroy (other.gameObject);
			Destroy(gameObject);
		}
		if (other.gameObject.tag == "Player") {
			if(gameObject.tag == "Enemy"){
				Destroy(other.gameObject);
				Debug.Log (gameObject.name);
			}
		}
		if (other.gameObject.tag == "Killwall") {
			if(gameObject.tag == "Enemy"){

				Destroy(gameObject);
				Debug.Log (gameObject.name);
			}
		}
	}
}
