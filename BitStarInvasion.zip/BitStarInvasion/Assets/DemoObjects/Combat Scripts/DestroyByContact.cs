﻿using UnityEngine;
using System.Collections;

public class DestroyByContact : MonoBehaviour
{
    public int maxEnemyHealth;
    private int currentHealth;
    public int damageValue;
    private int damageToPlayer;
    public int takeDamage;
	public AudioSource explosion;
    void Start()
    {
        currentHealth = maxEnemyHealth;
        SetDamageToPlayer(damageValue);
		explosion = GetComponent<AudioSource> ();
        
    }
    void SetDamageToPlayer(int damage)
    {
        damageToPlayer = damage;
    }
    void OnCollisionEnter(Collision other)
    {
        if (other.gameObject.tag == "Boundary")
        {
            return;
        }
        if (other.gameObject.tag == "Blast")
        {
            Destroy(other.gameObject);
            PlayerController play = GameObject.FindGameObjectWithTag("Player").GetComponent<PlayerController>();
            GaugeAPI xpbar = GameObject.FindGameObjectWithTag("XPBar").GetComponent<GaugeAPI>();
            currentHealth -= play.ApplyDamage();
            if (currentHealth <= 0)
            {
				explosion.Play();
                Destroy(gameObject);
                Debug.Log(xpbar.GetCurrent());
				xpbar.UpdateCurrent(xpbar.GetCurrent() + 300);
                if (xpbar.GetCurrent() >= xpbar.GetMax())
                {
                    float remaining = xpbar.GetCurrent() - xpbar.GetMax();
                    xpbar.UpdateMax(xpbar.GetMax() + 1000);
                    xpbar.UpdateCurrent(0);
                    xpbar.UpdateCurrent(remaining);
                }

            }
        }
        else if (other.gameObject.tag == "Player")
        {
            PlayerController play = GameObject.FindGameObjectWithTag("Player").GetComponent<PlayerController>();
            GaugeAPI healthbar = GameObject.FindGameObjectWithTag("HealthBar").GetComponent<GaugeAPI>();
            play.ReceiveDamage(damageToPlayer);
            if(play.PlayerHealth() > 0) {
                healthbar.UpdateCurrent(play.PlayerHealth());
            }
            else
            {
                healthbar.UpdateCurrent(0);
            }
            if (play.PlayerHealth() <= 0)
            {
                Destroy(other.gameObject);
            }

        }

        //  Destroy(other.gameObject);
        // Destroy(gameObject);
    }
}
