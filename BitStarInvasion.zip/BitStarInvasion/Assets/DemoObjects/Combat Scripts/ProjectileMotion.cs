﻿using UnityEngine;
using System.Collections;

public class ProjectileMotion : MonoBehaviour {
    private Rigidbody rb;
    public float speed;
    // Use this for initialization
    void Start()
    {
        rb = GetComponent<Rigidbody>();
        rb.velocity = transform.right * speed;
    }
}
