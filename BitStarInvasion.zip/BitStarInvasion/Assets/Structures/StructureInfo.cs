﻿using UnityEngine;
using System.Collections;

public class StructureInfo : GridBoundingObject {
	public string Name;

	public string Description;

	public float Cost;

	public float HP;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
