﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
namespace Util.Dictionary
{
	[System.Serializable]
	public class TableBase<TKey, TValue, Type> where Type : KeyValuePair<TKey, TValue>
	{
		[SerializeField]
		private List<Type>
			list;
		private Dictionary<TKey, TValue> table;
	
		public Dictionary<TKey, TValue> GetTable ()
		{
			if (table == null) {
				table = ConvertListToDictionary (list);
			}
			return table;
		}
	
		/// <summary>
		/// Editor Only
		/// </summary>
		public List<Type> GetList ()
		{
			return list;
		}
	
		static Dictionary<TKey, TValue> ConvertListToDictionary (List<Type> list)
		{
			Dictionary<TKey, TValue> dic = new Dictionary<TKey, TValue> ();
			foreach (KeyValuePair<TKey, TValue> pair in list) {
				dic.Add (pair.Key, pair.Value);
			}
			return dic;
		}
	}
}