﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

namespace Util.Dictionary
{
	[System.Serializable]
	public class KeyValuePair<TKey, TValue>
	{
		public TKey Key;
		public TValue Value;
	
		public KeyValuePair (TKey key, TValue value)
		{
			Key = key;
			Value = value;
		}

		public KeyValuePair (System.Collections.Generic.KeyValuePair<TKey, TValue> pair)
		{
			Key = pair.Key;
			Value = pair.Value;
		}
	}
}
