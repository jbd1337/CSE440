﻿using UnityEngine;
using System.Collections;
using System;

public class StructureSaveDataChunk
{
	public DateTime LastTime;	

	public StructureSaveData[] Structures;
}
