﻿using UnityEngine;
using System.Collections;

public class StructureSaveData : SavableSingleton<StructureSaveData> {

}
