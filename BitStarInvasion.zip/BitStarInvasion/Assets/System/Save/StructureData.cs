using UnityEngine;
public class StructureData
{
	public string StructureName;

	public Vector3 Position;
}