﻿using UnityEngine;
using System.Collections;

public class PlayerController : MonoBehaviour {

    // Use this for initialization
    public float speed;
    private Rigidbody rb;
    public GameObject shot;
    public Transform shotSpawn;
    private float nextFire = 0.0f;
    public float fireRate;
    private int damageRate;
    public int maxHealth;
    private int currentHealth;
    void Start () {
        rb = GetComponent<Rigidbody>();
        if (rb)
        {
            rb.freezeRotation = true;
        }
        SetDamage(5);
        currentHealth = maxHealth;
        GaugeAPI healthbar = GameObject.FindGameObjectWithTag("HealthBar").GetComponent<GaugeAPI>();
        healthbar.UpdateCurrent(currentHealth);
        healthbar.UpdateMax(maxHealth);
        GaugeAPI xpbar = GameObject.FindGameObjectWithTag("XPBar").GetComponent<GaugeAPI>();
        xpbar.UpdateCurrent(0);
        xpbar.UpdateMax(1000);
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetButton("Shoot") && Time.time > nextFire)
        {
            nextFire = Time.time + fireRate;
            Instantiate(shot, shotSpawn.position, shotSpawn.rotation);
        }
    }
    void FixedUpdate()
    {
        float moveHorizontal = Input.GetAxis("Horizontal");
        float moveVertical = Input.GetAxis("Vertical");
        Vector3 movement = new Vector3(moveHorizontal, 0.0f, moveVertical);
        rb.velocity = movement * speed;
    }
    void SetDamage(int damageValue)
    {
        damageRate = damageValue;
    }
    public int ApplyDamage()
    {
        return damageRate;
    }
    public void ReceiveDamage(int damage)
    {
        currentHealth -= damage;
    }
    public int PlayerHealth()
    {
        return currentHealth;
    }
}
