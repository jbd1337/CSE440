﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;


public class GaugeAPI : MonoBehaviour {
	public string TextTemplate;

	public float Max;

	private float Current;

	public Text TextComponent;

	public Slider SliderComponent;

	private Slider sliderComponent;
	// Use this for initialization
	void Start () {
		this.sliderComponent = this.SliderComponent??this.GetComponent<Slider> ();
	}
	
	// Update is called once per frame
	void Update () {
		this.TextComponent.text = string.Format (this.TextTemplate, this.Current, this.Max);
		this.sliderComponent.value = Current / Max;
	}
    public void UpdateCurrent(float currentValue)
    {
        Current = currentValue;
    }
    public void UpdateMax(float maxValue)
    {
        Max = maxValue;
    }
    public float GetCurrent()
    {
        return Current;
    }
    public float GetMax()
    {
        return Max;
    }
}
